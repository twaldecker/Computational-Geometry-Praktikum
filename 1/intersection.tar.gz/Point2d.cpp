#include "Point2d.h"

Point2d::Point2d( const float x, const float y ) :
    x( x ), y( y ) {

}

Point2d::~Point2d() {
  // TODO Auto-generated destructor stub
}

